CREATE TRIGGER `before_staff_insert`
BEFORE INSERT ON `staff`
FOR EACH ROW
  BEGIN
    SET NEW.setuptoken = uuid();
  END