CREATE VIEW `grade_total` AS
  SELECT
    `hofstad`.`grading`.`staff_id`             AS `staff_id`,
    `hofstad`.`grading`.`submission_id`        AS `submission_id`,
    round(avg(`hofstad`.`grading`.`grade`), 2) AS `final_grade`
  FROM `hofstad`.`grading`
  GROUP BY `hofstad`.`grading`.`staff_id`, `hofstad`.`grading`.`submission_id`